#include "coin_acceptor.h"
#include <avr/interrupt.h>
#include <util/delay.h>

// Running cent balance — incremented directly by INT0 ISR
static volatile uint32_t balance_cents = 0;

ISR(INT0_vect) {
    EIMSK &= ~(1 << INT0);          // Disable INT0 immediately

    _delay_ms(5); // Wait for bounce to settle

    // If still low after debounce, increment balance_cents
    if ((PIND & (1 << PIND2)) == 0) {
        balance_cents += PULSE_VALUE_CENTS;
    }

    // Now clear any flag that accumulated while we waited
    EIFR |= (1 << INTF0);

    // Safe to re-enable — line is confirmed idle
    EIMSK |= (1 << INT0);
}

void coin_acceptor_init(void) {

    // --- INT0 (PD2, Pin 2) — HX-916 coin pulse input ---
    DDRD  &= ~(1 << DDD2);     // PD2 as input
    PORTD &= ~(1 << PD2);      // No internal pull-up (use external 10kΩ)

    // Falling edge trigger (NO mode: line pulled HIGH, pulses LOW)
    EICRA |=  (1 << ISC01);
    EICRA &= ~(1 << ISC00);

    EIMSK |= (1 << INT0);      // Enable INT0
}

uint32_t coin_get_balance(void) {
    // balance_cents is uint32_t, not atomic on 8-bit AVR.
    // Disable interrupts briefly to read all 4 bytes consistently.
    uint32_t val;
    cli();
    val = balance_cents;
    sei();
    return val;
}

void coin_decrement(void) {
    cli();
    if (balance_cents > 0)
        balance_cents--;
    sei();
}